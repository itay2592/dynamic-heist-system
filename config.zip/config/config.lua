-- config.lua
Config = {
    PoliceResponseTime = 300,  -- Seconds before police respond
    HeistCooldown = 1800     -- Cooldown time for heists (seconds)
}
